# Flomo

PopClip extension for saving selected text to [flomo](https://flomoapp.com/).

## Configuration

Set flomo API URL in PopClip extension settings.

Get URL from:
[flomo incoming webhook](https://flomoapp.com/mine?source=incoming_webhook)

## About

- Requires flomo PRO account.